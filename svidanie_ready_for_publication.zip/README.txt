# Сайт-приглашение на свидание

Папка уже готова для публикации на GitHub Pages, Netlify или другом статическом хостинге.

## Что загружать
Загрузи **всё содержимое этой папки**, сохранив структуру:

- `index.html`
- `assets/photo-girl.jpg`
- `assets/photo-boy.jpg`

Главная страница — `index.html`.

## GitHub Pages
1. Создай новый публичный репозиторий на GitHub.
2. Загрузи `index.html` и папку `assets`.
3. Открой Settings → Pages.
4. В разделе Build and deployment выбери Deploy from a branch.
5. Выбери ветку `main` и папку `/ (root)`.
6. Сохрани. GitHub выдаст публичную ссылку вида `https://ИМЯ.github.io/ИМЯ-РЕПОЗИТОРИЯ/`.

Кнопки на сайте работают через обычный JavaScript, фотографии лежат отдельно в `assets`, а музыка открывается через YouTube.
